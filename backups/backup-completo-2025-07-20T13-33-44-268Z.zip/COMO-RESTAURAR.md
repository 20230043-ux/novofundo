# 🔄 GUIA COMPLETO DE RESTAURAÇÃO - FUNDO VERDE

## ⚠️ IMPORTANTE: ESTE BACKUP CONTÉM TUDO NECESSÁRIO PARA RESTAURAR O SITE COMPLETAMENTE

### 📋 CONTEÚDO DO BACKUP:
- ✅ Base de dados completa (todas as tabelas)
- ✅ Todos os arquivos de uploads (logos, fotos, comprovativos)
- ✅ Links das imagens dos ODS (Objetivos de Desenvolvimento Sustentável)
- ✅ Arquivos de configuração do sistema
- ✅ Dependências e package.json
- ✅ Arquivos públicos
- ✅ Schema da base de dados

### 🚀 PASSOS PARA RESTAURAÇÃO COMPLETA:

#### 1. PREPARAR AMBIENTE:
```bash
# 1. Criar novo projeto no Replit
# 2. Extrair este backup ZIP na raiz do projeto
# 3. Instalar dependências
npm install
```

#### 2. CONFIGURAR BASE DE DADOS:
```bash
# 1. Criar nova base de dados PostgreSQL (Neon Database)
# 2. Definir DATABASE_URL no .env
# 3. Aplicar schema
npm run db:push
# 4. Importar dados (ver pasta database/)
```

#### 3. RESTAURAR ARQUIVOS:
- Copiar pasta `uploads/` para raiz do projeto
- Copiar pasta `public/` para raiz do projeto
- Copiar arquivos de `sistema/` para raiz
- Copiar arquivos de `config/` para respetivos locais

#### 4. CONFIGURAR VARIÁVEIS:
```env
DATABASE_URL=sua_nova_database_url
SESSION_SECRET=sua_session_secret
```

#### 5. INICIAR APLICAÇÃO:
```bash
npm run dev
```

### 📊 DADOS INCLUÍDOS NO BACKUP:
- **SDGs**: Links de todas as imagens dos ODS (ver backup-metadata.json)
- **Utilizadores**: Todos os logins e dados de autenticação
- **Empresas**: Dados completos + logos + comprovativos
- **Pessoas**: Dados completos + fotos + comprovativos
- **Projetos**: Dados completos + imagens + atualizações
- **Investimentos**: Todos os registros de investimentos
- **Cálculos**: Todos os registros de pegada de carbono

### 🔗 LINKS DAS IMAGENS DOS ODS:
Todos os links das imagens dos ODS estão salvos em `backup-metadata.json` na seção `sdgImagesUrls`.

### ⚡ SISTEMA KEEP-ALIVE:
Este backup inclui o sistema completo de keep-alive para evitar hibernação no Replit.
Ver: REPLIT_KEEP_ALIVE_GUIDE.md

### 🆘 SUPORTE:
Se houver problemas na restauração:
1. Verificar se todas as variáveis de ambiente estão definidas
2. Confirmar que a base de dados está acessível
3. Verificar se as pastas uploads e public têm as permissões corretas
4. Consultar logs do servidor para mais detalhes

**Data do Backup**: 2025-07-20T13:33:45.305Z
**Versão**: 2.0.0 - Backup Completo Fundo Verde
