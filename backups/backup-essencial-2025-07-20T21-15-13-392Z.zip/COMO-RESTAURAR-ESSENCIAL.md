# Como Restaurar Backup Essencial

Este backup contém apenas os dados essenciais do Fundo Verde:

## Conteúdo Incluído:
- ✅ Todos os projetos com imagens e histórico de investimentos
- ✅ Todas as empresas com logos e históricos financeiros
- ✅ Todas as pessoas com fotos e históricos de cálculo
- ✅ Histórico completo de comprovativos de pagamento
- ✅ Histórico completo de investimentos
- ✅ Senhas dos utilizadores (hash bcrypt)
- ✅ Links de todas as imagens utilizadas

## Para Restaurar:
1. Extrair o arquivo ZIP
2. Importar os arquivos JSON da pasta 'database/' para o PostgreSQL
3. Copiar imagens da pasta 'uploads/' para o servidor
4. Verificar links de imagens no arquivo 'image_links.json'
5. As senhas estão preservadas e funcionarão imediatamente

## Dados NÃO Incluídos:
- Arquivos de sistema e configuração
- Dependências do Node.js
- Arquivos públicos
- Logs do sistema

Este backup é otimizado para migração rápida de dados críticos.
